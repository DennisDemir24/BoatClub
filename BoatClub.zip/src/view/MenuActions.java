package view;

public enum MenuActions {
    VIEW_COMPACT,
    VIEW_VERBOSE,
    CREATE_MEMBER,
    UPDATE_MEMBER_INFO,
    DELETE_MEMBER,
    VIEW_SPECIFIC_MEMBER,
    CREATE_BOAT,
    EDIT_BOAT,
    DELETE_BOAT,
    VIEW_BOAT,
    QUIT,
    DEFAULT
}
