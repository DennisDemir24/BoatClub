package model;

public enum BoatType {
        SAILBOAT,
        MOTORSAILER,
        KAYAK,
        CANOE,
        OTHER,
        DEFAULT
    }
