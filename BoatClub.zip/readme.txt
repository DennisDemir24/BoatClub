This was a group effort, the members and contributors are:
nh222mr - Nicklas Hansson
ph222ue - Patrik Hasselblad
dd222gc - Dennis Demir


How to run:
Make sure you have the latest JRE installed.
Open up a terminal and make your way to the archive where the BoatClub.jar is at.
boatType: java -jar BoatClub.jar.
Have fun!